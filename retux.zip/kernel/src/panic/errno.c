#include "panic/errno.h"

int errno = 0;
