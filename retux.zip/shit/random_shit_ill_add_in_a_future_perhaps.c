#include <stddef.h>
#include <stdint.h>

/* since libc is unavailable, function that compares the contents of two strings */
int strcmp(const char *str1, const char *str2) {
    while (*str1 && (*str1 == *str2)) {
        str1++;
        str2++;
    }
    return (unsigned char) *str1 - (unsigned char) *str2;
}

/* artificially create some delay */
void delay(int cycles) {
    for (int i = 0; i < cycles; i++) {
        // busy-wait loop
    }
}

/* ok so, this should be a simple keyboard input function, but because it's hardware specific and too hard
 * and time consuming for me to implement, i'll just return a placeholder key (in this case, 'a'), instead of
 * actually reading from the keyboard
 * actually i'm not adding that yet, lmao. fuck it.
 */
char get_key() {
	static int counter = 0;
	const char *simulated_input = "a\n";
	return simulated_input[counter++ % 3];
}

/* read characters one by one and append them to the buffer */
void get_input(char *buffer, size_t buffer_size) {
	size_t index = 0;
	while (index < buffer_size - 1) {
		char key = get_key();

		if (key == '\n') {
			buffer[index] = '\0';
			return;
		} else if (key == '\b') {
			if (index > 0) {
				index--;
			}
		} else {
			buffer[index++] = key;
		}
	}
	buffer[index] = '\0';
}

// check if input text is a command and if so handle it and execute the command
void handle_command(const char *command) {
	if (strcmp(command, "hello") == 0) {
		write_string("greetings to you too, fellow human being.\n");
	} else if (strcmp(command, "clear") == 0) {
		clear_screen();
	} else if (strcmp(command, "a") == 0) {
		write_string("hello again\n");
	} else {
		write_string("no such command, you moron\n");
	}
}

/* fill the whole vga buffer with blank spaces */
void clear_screen() {
	volatile uint16_t *vga_buffer = (uint16_t *) VGA_ADDRESS;
	uint8_t color = (COLOR_BLACK << 4) | COLOR_WHITE;
	for (size_t i = 0; i < VGA_WIDTH * VGA_HEIGHT; i++) {
		vga_buffer[i] = vga_entry(' ', color);
	}
}

// entry point
void kernel_main(void) {
    clear_screen();
    char command_buffer[256];
    while (1) {
        write_string("enter command (please :D): ");
        get_input(command_buffer, sizeof(command_buffer));
        handle_command(command_buffer);
        delay(100000);
    }
}









#include <stddef.h>
#include <stdint.h>

// vga
#define VGA_ADDRESS 0xB8000  // memory address of the vga buffer where chars and colors are stored
#define VGA_WIDTH 80  // 80 columns wide
#define VGA_HEIGHT 25  // 25 rows tall

// ps2
#define KEYBOARD_PORT 0x60  // data port
#define KEYBOARD_STATUS_PORT 0x64  // status port
#define KEYBOARD_BUFFER_FULL 0x01  // status flag for buffer full

// multiboot specification thing or idk for grub to work
// see: https://en.wikipedia.org/wiki/Multiboot_specification
__attribute__((section(".multiboot")))
const uint32_t multiboot_header[] = {
	0x1BADB002,  // grub magic number
	0x0, // flags
	-(0x1BADB002)  // checksum
};

// colors
enum vga_color {
	COLOR_BLACK = 0,
	COLOR_WHITE = 15,
};

static inline uint8_t inb(uint16_t port) 
{
    uint8_t value;
    __asm__ volatile ("inb %1, %0" : "=a"(value) : "Nd"(port));
    return value;
}

char scancode_to_char(uint8_t scancode) 
{
    // Basic keymap: Handle a few keys for demonstration
    switch (scancode) {
        case 0x1E: return 'a';
        case 0x30: return 'b';
        case 0x2E: return 'c';
        case 0x20: return 'd';
        case 0x12: return 'e';
        case 0x1C: return '\n';  // Enter
        default: return '?';     // Unknown key
    }
}


uint8_t keyboard_read(void) 
{
    while (!(inb(KEYBOARD_STATUS_PORT) & KEYBOARD_BUFFER_FULL)) {
        // wait until the keyboard buffer is full
    }
    return inb(KEYBOARD_PORT);
}


// please don't launch a drone strike to my location for putting the * adjacent to the variable name
// i'm just sticking to linux kernel coding style, since, well, i'm making a kernel lol

/* combine a character and its color into a 16 bit value */
uint16_t vga_entry(char c, uint8_t color) 
{
	return (uint16_t) c | (uint16_t) color << 8;
}

/* write a string to the vga buffer */
void write_string(const char* str) 
{
	volatile uint16_t *vga_buffer = (uint16_t *) VGA_ADDRESS;
	uint8_t color = (COLOR_BLACK << 4) | COLOR_WHITE;

	size_t offset = 0;
	for (size_t i = 0; str[i] != '\0'; i++) {
		vga_buffer[offset++] = vga_entry(str[i], color);
	}
}

/* entry point */
void kernel_main(void) {
    write_string("uhhhh hi i guess\n");

    while (1) {
        uint8_t scancode = keyboard_read();  // Read scancode from the keyboard
        if (scancode < 0x80) {  // Ignore key releases (scancodes >= 0x80)
            char c = scancode_to_char(scancode);  // Convert scancode to ASCII
            if (c != '?') {  // Only display known characters
                write_string(&c);  // Write character to the screen
            }
        }
    }
}
